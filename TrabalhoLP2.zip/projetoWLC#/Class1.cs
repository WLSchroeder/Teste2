﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;


namespace FWL
{
    class Jogador
    {
        public string Nome;
        public char Dificuldade;
        public double Tempo;
        public int JogosCompletos;
        public int Conquistas;
        public int Moedas;
        public bool Maçã;
        public bool Ampulheta;
        public bool Ticket;
        public bool Trevo;
        public bool Escudo;
        public bool Estrela;
        public Jogador(string n, char d)
        {
            Nome = n;
            Dificuldade = d;

        }

    }
    class CWL
    {

        public static void img1()
        {
            string vermelho = "\u001b[38;2;204;0;0m";
            Console.WriteLine(vermelho+"                     ███                                                               ███                       ");
            Console.WriteLine("                  █████                                                                 ████          ");
            Console.WriteLine("                ██████                      ██████████████████████                      ██████          ");
            Console.WriteLine("               ████████               ██████                      ██████                ████████         ");
            Console.WriteLine("              ██████████        ██████                                  ██████         █████████           ");
            Console.WriteLine("            ████████████████████                                              ████████████████████   ");
            Console.WriteLine("            ██████████████                                                          ██████████████            ");
            Console.WriteLine("            █████████████                                                          ███████████████       ");
            Console.WriteLine("            █████████████                                                          ███████████████       ");
            Console.WriteLine("            ███████████████                                                       ██████████████                   ");
            Console.WriteLine("              █████████████      █████                                █████       █████████████                     ");
            Console.WriteLine("                ███████████      █████████████                █████████████      █████████████                   ");
            Console.WriteLine("                   █████████      ████████████████        ████████████████        ███████████                     ");
            Console.WriteLine("                    █████          ████████████              ████████████             █████                       ");
            Console.WriteLine("                    ████           ████████████              ████████████             ████                          ");
            Console.WriteLine("                     ████          ████████████              ████████████            ████                         ");
            Console.WriteLine("                                    ██████████                ██████████                                          ");
        }
        public static void EscritaImg(string texto)
        {
            foreach (char c in texto)
            {
                Console.Write(c);
                if (c != ' ')
                {
                    Console.Beep(80, 5);
                }
                Thread.Sleep(1);
            }
            Thread.Sleep(3000);


        }
        public static void Escrita(string texto)
        {
            foreach (char c in texto)
            {
                Console.Write(c);
                if (c != ' ')
                {
                    Console.Beep(200, 5);
                }
                Thread.Sleep(8);
            }



        }
        public static int Seletor(bool jogo1, bool jogo2, bool jogo3, bool jogo4, bool tigrinho)
        {
            Console.Clear();    
            List<string> jogos = new List<string>();
            List<bool> jogoCompleto = new List<bool>();
            jogoCompleto.Add(false);
            jogoCompleto.Add(false);
            jogoCompleto.Add(false);
            jogoCompleto.Add(false);
            jogoCompleto.Add(false);
            jogoCompleto.Add(false);
            jogoCompleto.Add(false);
            if (jogo1 == true)
            {
                jogos.Add("Pedra Papel e Tesoura");
            }
            else
            {
                jogos.Add("Pedra Papel e Tesoura");
                jogoCompleto.Insert(0, true);
      
            }
            if (jogo2 == true)
            {
                jogos.Add("Simon");
            }
            else
            {
                jogos.Add("Simon");
                jogoCompleto.Insert(1, true);

            }
            if (jogo3 == true)
            {
                jogos.Add("Garrafas");
            }
            else
            {
                jogos.Add("Garrafas");
                jogoCompleto.Insert(2, true);

            }
            if (jogo4 == true)
            {
                
            }
            else
            {
                jogos.Add("");
                jogoCompleto.Insert(3, true);

            }
            jogos.Add("Feira do Rolo");
            if (tigrinho == true)
            {
                jogos.Add("Tigrinho");
            }

            int li = 0, co = 0, ppl = 3, ppc = 0, cont = 0, cont2 = -1, co2 = 0, y = 0;
            bool continuar = false;
            while (continuar == false)
            {
                for (cont = 0; cont < jogos.Count * 3; cont++)
                {



                    for (co = 0 + co2; co < 50; co++)
                    {
                        if (co == ppc && li == ppl)
                        {
                            Console.Write("██");
                            co += 2;
                        }
                        Console.Write(" ");
                    }

                    if (li % 3 == 0)
                    {
                        cont2++;
                        Console.Write(jogos[cont2]);
                        if (jogoCompleto[cont2] == true)
                        {
                            Console.Write("  ( Jogo Completo )");
                        }
                    }

                    Console.WriteLine("");
                    li++;
                    co = 0;

                }

                Console.WriteLine("\n\n\n");
                char resp = Console.ReadKey().KeyChar;
                if (resp == 'a' && ppc > 0)
                {
                    ppc -= 1;
                }
                else if (resp == 'w' && ppl > 0)
                {
                    ppl -= 1;
                }
                else if (resp == 's' && ppl < (jogos.Count - 1) * 3)
                {
                    ppl += 1;
                }
                else if (resp == 'd' && ppc < 47)
                {
                    ppc += 1;
                }

                if (ppl == 0 && ppc == 47)
                {

                    return 1;

                }
                else if (ppl == 3 && ppc == 47)
                {

                    return 2;
                }
                else if (ppl == 6 && ppc == 47)
                {

                    return 3;
                }
                else if (ppl == 9 && ppc == 47)
                {

                    return 4;
                }
                else if (ppl == 12 && ppc == 47)
                {
                    return 5;
                }
                else if (ppl == 15 && ppc == 47)
                {
                    return 6;
                }



                else if (resp == 2)
                {
                    return 10;
                }


                Console.Clear();
                cont2 = -1;
                li = 0;
            }
            return y;
        }
        public static int PPT(int Vidas)
        {
            string bot = null;
            int player = 0, npc = 0;
            char escolha='a';
            bool continua = true;
            while (continua == true)
            {
                player = 0;
                npc = 0;
                CWL.Escrita("Vozes do Além : Bem vindo ao Pedra, Papel e Tesoura, o jogo será melhor de 5, caso perca, perderá uma vida.\n\nVidas:");
                Console.Write(Vidas);
                while (player < 3 && npc < 3)
                {
                    for (int j = 0; j < 1; j++)
                    {
                        CWL.Escrita("\n\nVozes do Além : Faça sua escolha: ( 1 = Pedra ) ( 2 = Papel ) ( 3 = Tesoura )\n\n");
                        escolha = Console.ReadKey().KeyChar;
                        if (escolha != '1' && escolha != '2' && escolha != '3')
                        {
                            j = -1;
                            CWL.Escrita("Vozes do Além : Número inválido, escolha denovo");
                            Thread.Sleep(1000);
                            Console.Clear();
                        }
                    }
                    Random escolhaBot = new Random();
                    int x = escolhaBot.Next(1, 4);
                    if (x == 1)
                    {
                        bot = "Pedra";
                    }
                    else if (x == 2)
                    {
                        bot = "Papel";
                    }
                    else if (x == 3)
                    {
                        bot = "Tesoura";
                    }
                    Console.WriteLine($"\n\nEscolha do adversário:{bot}");
                    if (escolha == 'x')
                    {
                        Console.WriteLine("\n\n Empate");
                    }
                    else if (escolha == '1' && x == 2)
                    {
                        Console.WriteLine("\n\n Ponto para o bot!!");
                        npc++;
                    }
                    else if (escolha == '1' && x == 3)
                    {
                        Console.WriteLine("\n\n Ponto seu!!");
                        player++;
                    }
                    else if (escolha == '2' && x == 1)
                    {
                        Console.WriteLine("\n\n Ponto seu!!");
                        player++;
                    }
                    else if (escolha == '2' && x == 3)
                    {
                        Console.WriteLine("\n\n Ponto para o bot!!");
                        npc++;
                    }
                    else if (escolha == '3' && x == 1)
                    {
                        Console.WriteLine("\n\n Ponto para o bot!!");
                        npc++;
                    }
                    else if (escolha == '3' && x == 2)
                    {
                        Console.WriteLine("\n\n Ponto seu!!");
                        player++;
                    }

                    Console.WriteLine($"\n\nPlacar:{player}x{npc}");
                    Thread.Sleep(3000);
                    Console.Clear();

                }
                if (player == 3)
                {

                    CWL.Escrita("Vozes do Além : Parabéns, você conseguiu concluir o game!!!");
                    continua = false;
                    return 20 + Vidas;
                }
                else if (npc == 3)
                {
                    Vidas--;
                    if (Vidas == 0)
                    {

                        CWL.Escrita("Vozes do Além : GAME OVER!!");
                        return -1;

                    }
                    else
                    {
                        CWL.Escrita("Vozes do Além : HAHAHAHA, menos uma vida, deseja recomeçar?( 1 =  reiniciar ) ( 2 = voltar para o seletor de jogos )");
                        char escolha2 = Console.ReadKey().KeyChar;
                        if (escolha2 == '1')
                        {
                            return 10 + Vidas;

                        }
                        else if (escolha2 == '2')
                        {
                            return Vidas;
                        }

                    }



                }

            }

            return -1;
        }
        public static int Simon(int Vidas,char Dificuldade)
        {
            int j = 0, cont1 = 0, cont2 = 0, cont3 = 0, dificul = 0;
            int[,] matriz = new int[2, 15];
            bool continua = true;
            if (Dificuldade == '3')
            {
                dificul = 10;
            }
            else if (Dificuldade == '2')
            {
                dificul = 8;
            }
            else
            {
                dificul = 6;
            }
            while (continua == true)
            {

                CWL.Escrita("Vozes do Além : Bem vindo ao Simon, um jogo feito para testar sua memória, caso não consiga concluir, perderá uma vida.\n\nVidas:");
                Console.Write(Vidas);
                CWL.Escrita("\n\nVozes do Além : Diga a sequencia usando o seguinte método ( 1 = verde ) ( 2 = vermelho ) ( 3 = amarelo ) ( 4 = azul ): \n\n ");
                Console.Clear();
                for (int i = 1; i <= dificul; i++)
                {


                    Thread.Sleep(700);
                    Console.Clear();
                    CWL.Padrao();
                    Random escolhaBot = new Random();
                    matriz[cont1, cont2] = escolhaBot.Next(1, 4);
                    Thread.Sleep(500);

                    for (cont2 = 0; cont2 < i; cont2++)
                    {
                        if (matriz[cont1, cont2] == 1)
                        {
                            Console.Clear();
                            CWL.Verde();
                            Thread.Sleep(500);
                            Console.Clear();
                            CWL.Padrao();

                        }
                        else if (matriz[cont1, cont2] == 2)
                        {
                            Console.Clear();
                            CWL.Vermelho();
                            Thread.Sleep(500);
                            Console.Clear();
                            CWL.Padrao();
                        }
                        else if (matriz[cont1, cont2] == 3)
                        {
                            Console.Clear();
                            CWL.Amarelo();
                            Thread.Sleep(500);
                            Console.Clear();
                            CWL.Padrao();
                        }
                        else if (matriz[cont1, cont2] == 4)
                        {
                            Console.Clear();
                            CWL.Azul();
                            Thread.Sleep(500);
                            Console.Clear();
                            CWL.Padrao();
                        }

                    }
                    Console.WriteLine("\n\nSequencia:");
                    cont3 = cont2;
                    for (int k = 0; k < i; k++)
                    {

                        int resp = Convert.ToInt32(Console.ReadLine());
                        matriz[cont1 + 1, cont2] = resp;
                        if (resp != matriz[cont1, cont2 - cont3])
                        {
                            Vidas--;
                            i = 50;
                            k = 50;
                            cont2 = 0;
                            if (Vidas == 0)
                            {
                                CWL.Escrita("Vozes do Além : GAME OVER");
                                return -1;
                            }
                            CWL.Escrita("Vozes do Além : HAHAHAHA,RESPOSTA ERRADA!! Menos uma vida, deseja recomeçar?( 1 =  reiniciar ) ( 2 = voltar para o seletor de jogos )");
                            char escolha2 = Console.ReadKey().KeyChar;
                            if (escolha2 == '1')
                            {
                                return 10 + Vidas;
                            }
                            else if (escolha2 == '2')
                            {
                                return Vidas;
                            }
                        }
                        cont3--;
                    }
                }
                return 20 + Vidas;

            }
            return 0;

        }
        public static int Garrafas(int Vidas, char Dificuldade)
        {
            int indiceSorteado = 0;
            List<int> sort1 = new List<int>();
            List<int> sort2 = new List<int>();
            int[,] matriz = new int[3, 15];
            int dificul = 0, chances = 0;
            int cont = 0, teste = 0;
            bool continua = true, continuarGame = true;
            int valor1, valor2, resp1, resp2;
            if (Dificuldade == '3')
            {
                sort1.Add(0);
                sort1.Add(1);
                sort1.Add(2);
                sort1.Add(3);
                sort1.Add(4);
                sort1.Add(5);
                sort1.Add(6);
                teste = 6;
                sort2.Add(0);
                sort2.Add(1);
                sort2.Add(2);
                sort2.Add(3);
                sort2.Add(4);
                sort2.Add(5);
                sort2.Add(6);
                chances = 20;
            }
            else if (Dificuldade == '2')
            {
                sort1.Add(0);
                sort1.Add(1);
                sort1.Add(2);
                sort1.Add(3);
                sort1.Add(4);
                sort1.Add(5);
                teste = 5;
                sort2.Add(0);
                sort2.Add(1);
                sort2.Add(2);
                sort2.Add(3);
                sort2.Add(4);
                sort2.Add(5);
                chances = 10;
            }
            else
            {
                sort1.Add(0);
                sort1.Add(1);
                sort1.Add(2);
                sort1.Add(3);
                teste = 3;
                sort2.Add(0);
                sort2.Add(1);
                sort2.Add(2);
                sort2.Add(3);
                chances = 5;
            }
            CWL.Escrita("Vozes do Além : Seja bem vindo ao jogo Garrafas, um jogo feito para testar sua lógica, caso não descubra a ordem, perderá uma vida. \n\n Vidas:");
            Console.WriteLine(Vidas);
            Random random = new Random();
            while (sort1.Count > 0) // sorteia a sequencia do jogo
            {
                indiceSorteado = random.Next(0, sort1.Count);

                matriz[1, cont] = sort1[indiceSorteado];
                sort1.RemoveAt(indiceSorteado);

                cont++;
            }
            bool continuar = true;
            cont = 0;

            while (sort2.Count > 0) // sorteia a resposta
            {


                continuar = true;

                while (continuar == true)
                {
                    indiceSorteado = random.Next(0, sort2.Count);
                    matriz[2, cont] = sort2[indiceSorteado];
                    if (matriz[2, cont] == matriz[1, cont])
                    {
                        continuar = true;
                    }
                    else
                    {
                        continuar = false;
                    }
                }
                matriz[2, cont] = sort2[indiceSorteado];

                sort2.RemoveAt(indiceSorteado);
                cont++;
            }
            while (continuarGame = true)
            {
                int gambiarra = CWL.GarrafasCores(teste, matriz, chances);
                chances--;
                if (gambiarra == 1)
                {
                    return 20 + Vidas;
                }
                else if (gambiarra == 0)
                {
                    Vidas--;
                    if (Vidas == 0)
                    {
                        Console.WriteLine("GAMER OVER!!!");
                        return -1;
                    }
                    Thread.Sleep(200);
                    Console.Clear();
                    CWL.Escrita("Vozes do Além : HAHAHAHA,ACABARAM AS CHANCES!! Menos uma vida, deseja recomeçar?( 1 =  reiniciar ) ( 2 = voltar para o seletor de jogos )");
                    int gambiarra2 = Convert.ToInt32(Console.ReadLine());
                    if (gambiarra2 == 1)
                    {
                        return 10 + Vidas;
                    }
                    else if (gambiarra2 == 2)
                    {
                        return Vidas;
                    }

                }

                resp1 = Convert.ToInt32(Console.ReadLine());
                resp2 = Convert.ToInt32(Console.ReadLine());
                valor1 = matriz[1, resp1 - 1];
                valor2 = matriz[1, resp2 - 1];
                matriz[1, resp1 - 1] = valor2;
                matriz[1, resp2 - 1] = valor1;
            }
            return 0;
        }

        public static int Sudoku(int Vidas, int Dificuldade)
        {
            int indiceSorteado = 0;
            int[,] matriz = new int[9, 9];
            int linha = 0, coluna = 0, cubo = 0, gambiarra1, gambiarra2, teste1, teste2;
            bool PodeIrLinha = true, PodeIrColuna = true, PodeIrCubo = true, PodeIr = false;
            List<int> sort1 = new List<int>();


            Random random = new Random();
            for (linha = 0; linha < 9; linha++)
            {
                sort1.Add(1);
                sort1.Add(2);
                sort1.Add(3);
                sort1.Add(4);
                sort1.Add(5);
                sort1.Add(6);
                sort1.Add(7);
                sort1.Add(8);
                sort1.Add(9);
                for (coluna = 0; coluna < 9; coluna++)
                {
                    PodeIrLinha = true;
                    PodeIrColuna = true;
                    PodeIrCubo = true;
                    PodeIr = false;
                    while (!PodeIr)
                    {
                        indiceSorteado = random.Next(0, sort1.Count);
                        for (int a = 0; a < linha; a++)
                        {
                            if ((indiceSorteado + 1) == matriz[a, coluna])
                            {
                                PodeIrLinha = false;
                            }

                        }
                        for (int b = 0; b < coluna; b++)
                        {
                            if ((indiceSorteado + 1) == matriz[linha, b])
                            {
                                PodeIrColuna = false;
                            }
                        }
                        double x = Convert.ToDouble(linha);
                        double y = Convert.ToDouble(coluna);
                        double z = x / 3;
                        double zz = y / 3;
                        if (z < 1)
                        {
                            if (zz < 1)
                            {
                                gambiarra1 = 0;
                                gambiarra2 = 0;
                            }
                            else if (zz < 2)
                            {
                                gambiarra1 = 0;
                                gambiarra2 = 3;
                            }
                            else
                            {
                                gambiarra1 = 0;
                                gambiarra2 = 6;
                            }
                        }
                        else if (z < 2)
                        {
                            if (zz < 1)
                            {
                                gambiarra1 = 3;
                                gambiarra2 = 0;
                            }
                            else if (zz < 2)
                            {
                                gambiarra1 = 3;
                                gambiarra2 = 3;
                            }
                            else
                            {
                                gambiarra1 = 3;
                                gambiarra2 = 6;
                            }
                        }
                        else
                        {
                            if (zz < 1)
                            {
                                gambiarra1 = 6;
                                gambiarra2 = 0;
                            }
                            else if (zz < 2)
                            {
                                gambiarra1 = 6;
                                gambiarra2 = 3;
                            }
                            else
                            {
                                gambiarra1 = 6;
                                gambiarra2 = 6;
                            }
                        }
                        for (int cl = linha; cl > gambiarra1; cl--)
                        {
                            for (int cc = coluna; cc > gambiarra2; cc--)
                            {
                                if ((indiceSorteado + 1) == matriz[cl, cc])
                                {
                                    PodeIrCubo = false;
                                }

                            }

                        }
                        if (PodeIrLinha)
                        {
                            if (PodeIrColuna)
                            {
                                if (PodeIrCubo)
                                {
                                    PodeIr = true;
                                }
                            }
                        }

                    }

                    matriz[linha, coluna] = (indiceSorteado + 1);
                    Console.WriteLine(matriz[linha, coluna] + "  " + linha + "   " + coluna);
                    sort1.RemoveAt(indiceSorteado);



                }
            }
            /* for (int teste1 = 0; teste1 < 9; teste1++)
             {
                 Console.WriteLine("linha:" + (teste1+1));
                 for(int teste2= 0; teste2 < 9; teste2++)
                 {
                     Console.WriteLine(matriz[teste1,teste2]);
                 }
             }*/

            return 0;

        }
        public static void Padrao()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public static void Verde()
        {
            string verdeRGB = "\u001b[38;2;0;128;0m";

            Console.Write(verdeRGB + "           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(verdeRGB + "           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(verdeRGB + "           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(verdeRGB + "           ██████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.Write(verdeRGB + "           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public static void Vermelho()
        {
            string vermelhoRGB = "\u001b[38;2;200;30;30m";
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(vermelhoRGB + "██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(vermelhoRGB + "██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(vermelhoRGB + "██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(vermelhoRGB + "        ██████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(vermelhoRGB + "██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public static void Amarelo()
        {
            string amareloRGB = "\u001b[38;2;220;220;0m";
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(amareloRGB + "           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(amareloRGB + "           ██████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(amareloRGB + "           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(amareloRGB + "           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(amareloRGB + "           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public static void Azul()
        {
            string azulRGB = "\u001b[38;2;0;0;200m";
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██████████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("        ██████");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████  ██");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(azulRGB + "██  ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(azulRGB + "        ██████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(azulRGB + "██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(azulRGB + "██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("           ██████████");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine(azulRGB + "██████████");
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public static int GarrafasCores(int x, int[,] matriz, int chances)
        {
            List<string> cor = new List<string>();

            cor.Add("\u001b[38;2;230;25;75m");
            cor.Add("\u001b[38;2;60;180;75m");
            cor.Add("\u001b[38;2;0;130;200m");
            cor.Add("\u001b[38;2;255;225;25m");
            cor.Add("\u001b[38;2;245;130;48m");
            cor.Add("\u001b[38;2;145;30;180m");
            cor.Add("\u001b[38;2;218;112;214m");
            int i = 0, cont = x;
            int certas = 0;
            Console.Clear();
            for (i = 0; i < cont; i++)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("     ████  ");
                if (i == cont - 1)
                {
                    Console.WriteLine("     ████  ");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "      ██   ");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "      ██   ");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "     ████  ");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "     ████  ");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "    ██████ ");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "    ██████ ");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "    ██████ ");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "    ██████ ");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "    ██████ ");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "    ██████ ");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ████████");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ████████");
                }
            }
            for (i = 0; i < cont; i++)
            {
                Console.Write(cor[matriz[1, i]] + "   ██ ██ ██");
                if (i == cont - 1)
                {
                    Console.WriteLine(cor[matriz[1, i + 1]] + "   ██ ██ ██");
                }
            }
            for (i = 0; i <= cont; i++)
            {
                if (cor[matriz[1, i]] == cor[matriz[2, i]])
                {
                    certas++;
                }

            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\nCertas: " + certas);
            Console.WriteLine("\nChances: " + chances);
            if (chances <= 0 && certas <= cont)
            {

                return 0;
            }
            else if (certas >= cont)
            {
                return 1;
            }
            return -1;
        }

        public static void Feira(int Moedas)
        {
            bool continuar=true;
            int lado = 100;
            Jogador gambiarra = new Jogador("dms", '2');
            while (continuar==true)
            {
                if (lado % 2 == 0)
                {
                    Console.Clear();
                    int sópraencherlinguica=Console.ReadKey().KeyChar;
                    CWL.Feirante1();
                    CWL.Escrita("Flávio: Tranquilo meu amigo? O que deseja?");
                    Console.WriteLine("\n\nClique ( 1 = Maçã ) ( 2 = Ampulheta ) ( 3 = Ticket ? ) para ver a descrição do objeto ou comprar!! Também pode clicar ( D = Loja à Direita), ( A = Loja à Esquerda) ou ( P = Sair da feira )");
                    char resp = Console.ReadKey().KeyChar;
                    /*if(resp == 1)
                    {  
                        Console.WriteLine("\n\nMaçã: Um fruta ultra nutritiva feita para melhorar sua saúde. ( Preço : 5 )\n\nDeseja comprar? ( 1 = Sim ) ( 2 = Não )");
                        char compra = Console.ReadKey().KeyChar;
                        if (Moedas>=5 & compra == '1')
                        {
                            Moedas -= 5;

                            Console.WriteLine("Compra Feita com sucesso!!");


                        }
                        else
                        {

                        }
                    }*/

                    if (resp == 'a' || resp == 'A')
                    {
                        lado--;
                    }
                    else if (resp == 'd' || resp == 'D')
                    {
                        lado++;
                    }
                    else if(resp=='p' || resp == 'P')
                    {
                        Console.Clear();
                        continuar = false;
                    }
                }
                else if ((lado-1) % 2 == 0)
                {
                    Console.Clear();
                    CWL.Feirante2();
                    CWL.Escrita("Bianca: Olá, tudo bem? Desejas algo?");
                    Console.WriteLine("\n\nClique ( 1 = Trevo ) ( 2 = Escudo ) ( 3 = Estrela ) para ver a descrição do objeto ou comprar!! Também pode clicar ( D = Loja à Direita), ( A = Loja à Esquerda) ou ( P = Sair da feira )");
                    char resp = Console.ReadKey().KeyChar;
                    if (resp == 'a' || resp == 'A')
                    {
                        lado--;
                    }
                    else if (resp == 'd' || resp == 'D')
                    {
                        lado++;
                    }
                    else if (resp == 'p' || resp == 'P')
                    {
                        Console.Clear();
                        continuar = false;
                    }
                }
            }
        }
        public static void Feirante1()
        {
            List<string> cor = new List<string>();
            cor.Add("\u001b[38;2;92;51;23m");
            cor.Add("\u001b[38;2;210;180;140m");
            cor.Add("\u001b[38;2;60;40;20m");
            cor.Add("\u001b[38;2;70;130;180m");
            cor.Add("\u001b[38;2;204;0;0m");
            cor.Add("\u001b[38;2;255;255;255m");
            cor.Add("\u001b[38;2;205;92;92m");
            cor.Add("\u001b[38;2;128;128;128m");
            cor.Add("\u001b[38;2;237;201;175m");
            cor.Add("\u001b[38;2;139;69;19m");
            cor.Add("\u001b[38;2;255;215;0m");

            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[6] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[6] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[6] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[6] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[6] + "█████████████████████████████████████████████████████████████████████████████");

            Console.WriteLine(cor[0] + "███                                                       " + cor[10] + "█████▄▄▄█████   " + cor[0] + "███");

            Console.WriteLine("███                            " + cor[9] + "▄▄▄▄▄▄▄▄▄▄▄▄▄▄" + cor[10] + "             ▄█▄█▄█▄█▄█▄█▄" + cor[0] + "   ███");

            Console.WriteLine("███          " + cor[9] + "▄▀▄                " + cor[7] + "████████████" + cor[10] + "              █████████████" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + "   ▄▄▄ █ ▄▄▄ " + cor[8] + "               ▀████████▀" + cor[10] + "               ███       ███" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + "  ███████████ " + cor[8] + "                ▀████▀" + cor[10] + "                 ██   ███   ██" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + " █████████████ " + cor[8] + "                 ██" + cor[10] + "                   ███████   ███" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + " █████████████ " + cor[8] + "              ▄██████▄" + cor[10] + "                ██████  █████" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + " █████████████ " + cor[8] + "             ██████████" + cor[10] + "               █████████████" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + "  ███████████ " + cor[8] + "             ████████████" + cor[10] + "              █████   █████" + cor[0] + "   ███");

            Console.WriteLine("███  " + cor[4] + "   ▀▀▀▀ ▀▀▀▀ " + cor[9] + "             ▀▀▀▀▀▀▀▀▀▀▀▀▀▀" + cor[10] + "              ▀▀▀▀▀▀▀▀▀▀▀" + cor[0] + "    ███");

            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███             ██████████████████████████████████████████");
            Console.WriteLine("███                                                                       ███             ████      ███████      █       █      ████");
            Console.WriteLine("███                                                                       ███             ████████  ███████  ██  █  ███  █  ██  ████");
            Console.WriteLine("███                                                                       ███             ████      ███████      █  ███  █       ███");

            Console.Write("███                               ");
            Console.Write(cor[2] + "██████████");
            Console.WriteLine(cor[0] + "                              ███             ████████  ███████  █████  ███  █  ███  ███");

            Console.Write(cor[0] + "███                               ");
            Console.Write(cor[1] + "██▄▄██▄▄██");
            Console.WriteLine(cor[0] + "                              ███             ████      ███████  █████       █  ███  ███");

            Console.Write(cor[0] + "███                               ");
            Console.Write(cor[1] + "██  ██  ██");
            Console.WriteLine(cor[0] + "                              ███             ██████████████████████████████████████████");

            Console.Write(cor[0] + "███                               ");
            Console.Write(cor[1] + "██▄▄██▄▄██");
            Console.WriteLine(cor[0] + "                              ███             █████████████    ███       ███████████████");

            Console.Write(cor[0] + "███                               ");
            Console.Write(cor[1] + "██ ▀▀▀▀ ██");
            Console.WriteLine(cor[0] + "                              ███             █████████████ █  ███  ███  ███████████████");

            Console.Write(cor[0] + "███                               ");
            Console.Write(cor[1] + "██████████");
            Console.WriteLine(cor[0] + "                              ███             ███████████████  ███  ███  ███████████████");

            Console.Write(cor[0] + "███                            ");
            Console.Write(cor[3] + "███████" + cor[1] +
                "██" + cor[3] +
                "███████");
            Console.WriteLine(cor[0] + "                           ███             ███████████████  ███  ███  ███████████████");

            Console.Write(cor[0] + "███                           ");
            Console.Write(cor[3] + "██ ████████████ ██");
            Console.WriteLine(cor[0] + "                          ███             █████████████      █       ███████████████");

            Console.Write(cor[0] + "███                          ");
            Console.Write(cor[1] + "██" + cor[3] +
                "  ████████████  " + cor[1] +
                "██");
            Console.WriteLine(cor[0] + "                         ███             ██████████████████████████████████████████");

            Console.WriteLine(cor[0] + "█████████████████████████████████████████████████████████████████████████████                               ████");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ████");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ████");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ████");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ████");
            Console.WriteLine("███                                                                       ███                               ████");
            Console.WriteLine("███                                                                       ███                               ████");
            Console.ForegroundColor = ConsoleColor.White;

        }
        
        public static void Feirante2()
        {
            List<string> cor = new List<string>();
            cor.Add("\u001b[38;2;92;51;23m");
            cor.Add("\u001b[38;2;210;180;140m");
            cor.Add("\u001b[38;2;101;45;15m");
            cor.Add("\u001b[38;2;180;150;255m");
            cor.Add("\u001b[38;2;204;0;0m");
            cor.Add("\u001b[38;2;255;255;255m");
            cor.Add("\u001b[38;2;205;92;92m");
            cor.Add("\u001b[38;2;128;128;128m");
            cor.Add("\u001b[38;2;237;201;175m");
            cor.Add("\u001b[38;2;139;69;19m");
            cor.Add("\u001b[38;2;255;215;0m");
            cor.Add("\u001b[38;2;60;160;60m");
            cor.Add("\u001b[38;2;20;100;20m");
            cor.Add("\u001b[38;2;219;219;219m"); // prata do escudo
            cor.Add("\u001b[38;2;255;0;0m"); // vermelho do escudo
            cor.Add("\u001b[38;2;180;150;255m"); // azul barraca
            cor.Add("\u001b[38;2;255;215;0m"); // amarelo da estrela

            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[15] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[15] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[15] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[15] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[5] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[15] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine(cor[0] + "███   " + cor[11] + "▄▄▄▄▄" + "      ▄▄▄▄▄       " + cor[14] + " ▄▄▄▄▄▄▄▄" + cor[13] + "▄▄▄▄▄▄▄                " + cor[16] + "▄█▄          " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███ " + cor[11] + "▄███████▄" + " ▄███████▄     " + cor[14] + " █████████" + cor[13] + "████████              " + cor[16] + "▄███▄         " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███ " + cor[11] + "█████████" + cor[12] + "█" + cor[11] + "█████████  " + cor[14] + "    █████████" + cor[13] + "████████             " + cor[16] + "▄█████▄        " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███  " + cor[11] + "▀███████" + cor[12] + "█" + cor[11] + "███████▀    " + cor[14] + "   █████████" + cor[13] + "████████      " + cor[16] + "▀███████████████████▀ " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███   " + cor[12] + "▄█████████████▄     " + cor[14] + "   █████████" + cor[13] + "████████        " + cor[16] + "▀███████████████▀   " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███  " + cor[11] + "████████" + cor[12] + "█" + cor[11] + "████████   " + cor[13] + "    █████████" + cor[14] + "████████          " + cor[16] + "▀███████████▀     " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███ " + cor[11] + "█████████" + cor[12] + "█" + cor[11] + "█████████     " + cor[13] + "  ████████" + cor[14] + "███████            " + cor[16] + "███████████      " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███  " + cor[11] + "████████" + cor[12] + "█" + cor[11] + "████████      " + cor[13] + "   ███████" + cor[14] + "██████            " + cor[16] + "█████▀▀▀█████     " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███    " + cor[11] + "▀▀▀▀ " + cor[12] + "▄█" + cor[11] + "  ▀▀▀▀       " + cor[13] + "     ▀█████" + cor[14] + "████▀            " + cor[16] + "████▀     ▀████    " + cor[0] + "███");
            Console.WriteLine(cor[0] + "███       " + cor[12] + "▄█▀" + cor[11] + "                   " + cor[13] + "  ▀▀▀▀" + cor[14] + "▀▀▀             " + cor[16] + "▄██▀         ▀██▄   " + cor[0] + "███");
            Console.WriteLine(cor[0] + "█████████████████████████████████████████████████████████████████████████████");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");
            Console.WriteLine("███                                                                       ███");

            Console.Write("███                             "+cor[2] + "▄█");
            Console.Write(cor[2] + "███████████▄");
            Console.WriteLine(cor[0] + "                            ███             "); 

            Console.Write(cor[0] + "███                             "+cor[2] + "██");
            Console.Write(cor[1] + "██▄▄██▄▄██"+cor[2] + "██");
            Console.WriteLine(cor[0] + "                            ███             ");

            Console.Write(cor[0] + "███                             "+cor[2] + "██");
            Console.Write(cor[1] + "██  ██  ██"+cor[2] + "██");
            Console.WriteLine(cor[0] + "                            ███             ");

            Console.Write(cor[0] + "███                             "+cor[2] + "██");
            Console.Write(cor[1] + "██▄▄██▄▄██"+cor[2] + "██");
            Console.WriteLine(cor[0] + "                            ███             ");

            Console.Write(cor[0] + "███                            "+cor[2] + " ██");
            Console.Write(cor[1] + "██ ▀▀▀▀ ██"+cor[2] + "██");
            Console.WriteLine(cor[0] + "                            ███             ");

            Console.Write(cor[0] + "███                            "+cor[2] + "▄██");
            Console.Write(cor[1] + "██████████"+cor[2] + "██▄");
            Console.WriteLine(cor[0] + "                           ███             ");

            Console.Write(cor[0] + "███                            ");
            Console.Write(cor[3] + "███████" + cor[1] +
                "██" + cor[3] +
                "███████");
            Console.WriteLine(cor[0] + "                           ███             ");

            Console.Write(cor[0] + "███                           ");
            Console.Write(cor[3] + "██ ████████████ ██");
            Console.WriteLine(cor[0] + "                          ███             ");

            Console.Write(cor[0] + "███                          ");
            Console.Write(cor[1] + "██" + cor[3] +"  ████████████  " + cor[1] +"██");
            Console.WriteLine(cor[0] + "                         ███             ");

            Console.WriteLine(cor[0] + "█████████████████████████████████████████████████████████████████████████████                               ");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ");
            Console.WriteLine("█████████████████████████████████████████████████████████████████████████████                               ");
            Console.WriteLine("███                                                                       ███                               ");
            Console.WriteLine("███                                                                       ███                               ");
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static int Tigrinho(int moedas)
        {
            int aposta = 10000;
            CWL.Escrita("Litle Tiger : Seja bem vindo a SchroederBet, unica casa de aposta do planeta que você não perde sua dignidade, só seu patrimonio...Você pode multiplicar suas moedas até 5x. deseja apostar quantas das suas moedas?\n(Obs: caso não queira apostar nada, digite 0. Seu ticket não será reembolsado.)\n\nMoedas:" + moedas+"\n\n");
            while (aposta > moedas)
            {
                aposta = Convert.ToInt32(Console.ReadLine());
                if (aposta > moedas || aposta<0)
                {
                    Console.WriteLine("Valor inválido");
                }
                else if (aposta == 0)
                {
                    return -1;
                    
                }
            }
            Console.WriteLine("Aposta feita ("+aposta+")");
            CWL.Escrita("Vamos la");
            Thread.Sleep(1000);
            Console.Clear();    
            int resposta=CWL.TigrinhoRoleta();
            Thread.Sleep(1000);
            Console.ForegroundColor = ConsoleColor.White;
            CWL.Escrita($"Litle Tiger : Parabéns,você multiplicou suas moedas por: {resposta} e agora elas se tornaram {aposta * resposta} moedas.\n\nEspero que tenha gostado ");

            return 1;

        }
        public static int TigrinhoRoleta()
        {
            int velocidade = 1;
            List<string> cor = new List<string>();
            cor.Add("\u001b[38;2;0;255;255m");
            cor.Add("\u001b[38;2;57;255;20m");
            cor.Add("\u001b[38;2;255;215;0m");
            cor.Add("\u001b[38;2;138;43;226m");
            cor.Add("\u001b[38;2;255;0;0m");
            cor.Add("\u001b[38;2;255;255;255m");
            Thread.Sleep(1000);
            Random sorteioDuLitleTiger = new Random();
            int i = sorteioDuLitleTiger.Next(80, 120);
            for(int k = 0; k<3;k++)
            {
                velocidade *= 2;
                for (int j = 4; j < i / velocidade; j++)
                {
                    if (j % 4 == 0)
                    {
                        Console.WriteLine(cor[0] + "                     ██████" + cor[1] + "██████               ");
                        Console.WriteLine(cor[0] + "                  █████████" + cor[1] + "█████████                    ");
                        Console.WriteLine(cor[0] + "                ███████████" + cor[1] + "███████████            ");
                        Console.WriteLine(cor[0] + "              █████████████" + cor[1] + "█████████████                        ");
                        Console.WriteLine(cor[0] + "              ██████" + cor[5] + "X4" + cor[0] + "█████" + cor[1] + "█████" + cor[5] + "X2" + cor[1] + "██████                      ");
                        Console.WriteLine(cor[0] + "            ███████████████" + cor[1] + "███████████████                       ");
                        Console.WriteLine(cor[0] + "            ███████████████" + cor[1] + "███████████████                     ");
                        Console.WriteLine(cor[0] + "           ████████████████" + cor[1] + "████████████████                     ");
                        Console.WriteLine(cor[2] + "           ████████████████" + cor[3] + "████████████████                     ");
                        Console.WriteLine(cor[2] + "            ███████████████" + cor[3] + "███████████████                     ");
                        Console.WriteLine(cor[2] + "            ███████████████" + cor[3] + "███████████████                 ");
                        Console.WriteLine(cor[2] + "              ██████" + cor[5] + "X0" + cor[2] + "█████" + cor[3] + "█████" + cor[5] + "X5" + cor[3] + "██████                     ");
                        Console.WriteLine(cor[2] + "              █████████████" + cor[3] + "█████████████                     ");
                        Console.WriteLine(cor[2] + "                ███████████" + cor[3] + "███████████                     ");
                        Console.WriteLine(cor[2] + "                  █████████" + cor[3] + "█████████");
                        Console.WriteLine(cor[2] + "                     ██████" + cor[3] + "██████");
                        Console.WriteLine(cor[4] + "                                    ");
                        Console.WriteLine("                     ▄▄               ");
                        Console.WriteLine("                   ▄████▄               ");
                        Console.WriteLine("                 ▄████████▄                ");
                        Console.WriteLine("                    ████            ");
                        Console.WriteLine("                    ████              ");
                        Console.WriteLine("                    ████              ");
                        if (velocidade == 2)
                        {
                            Thread.Sleep(150);
                            Console.Clear();
                        }
                        else if (velocidade == 4)
                        {
                            Thread.Sleep(400);
                            Console.Clear();
                        }
                        else if (velocidade == 8)
                        {
                            if (j == (i / 8) - 1)
                            {
                                return 0;
                            }
                            else
                            {
                                Thread.Sleep(700);
                                Console.Clear();
                            }
                        }

                    }
                    else if ((j - 1) % 4 == 0)
                    {
                        Console.WriteLine(cor[2] + "                     ██████" + cor[0] + "██████               ");
                        Console.WriteLine(cor[2] + "                  █████████" + cor[0] + "█████████                    ");
                        Console.WriteLine(cor[2] + "                ███████████" + cor[0] + "███████████            ");
                        Console.WriteLine(cor[2] + "              █████████████" + cor[0] + "█████████████                        ");
                        Console.WriteLine(cor[2] + "              ██████" + cor[5] + "X0" + cor[2] + "█████" + cor[0] + "█████" + cor[5] + "X4" + cor[0] + "██████                      ");
                        Console.WriteLine(cor[2] + "            ███████████████" + cor[0] + "███████████████                       ");
                        Console.WriteLine(cor[2] + "            ███████████████" + cor[0] + "███████████████                     ");
                        Console.WriteLine(cor[2] + "           ████████████████" + cor[0] + "████████████████                     ");
                        Console.WriteLine(cor[3] + "           ████████████████" + cor[1] + "████████████████                     ");
                        Console.WriteLine(cor[3] + "            ███████████████" + cor[1] + "███████████████                     ");
                        Console.WriteLine(cor[3] + "            ███████████████" + cor[1] + "███████████████                  ");
                        Console.WriteLine(cor[3] + "              ██████" + cor[5] + "X5" + cor[3] + "█████" + cor[1] + "█████" + cor[5] + "X2" + cor[1] + "██████                      ");
                        Console.WriteLine(cor[3] + "              █████████████" + cor[1] + "█████████████                     ");
                        Console.WriteLine(cor[3] + "                ███████████" + cor[1] + "███████████                     ");
                        Console.WriteLine(cor[3] + "                  █████████" + cor[1] + "█████████");
                        Console.WriteLine(cor[3] + "                     ██████" + cor[1] + "██████");
                        Console.WriteLine(cor[4] + "                                    ");
                        Console.WriteLine("                     ▄▄               ");
                        Console.WriteLine("                   ▄████▄               ");
                        Console.WriteLine("                 ▄████████▄                ");
                        Console.WriteLine("                    ████            ");
                        Console.WriteLine("                    ████              ");
                        Console.WriteLine("                    ████              ");
                        if (velocidade == 2)
                        {
                            Thread.Sleep(150);
                            Console.Clear();
                        }
                        else if (velocidade == 4)
                        {
                            Thread.Sleep(400);
                            Console.Clear();
                        }
                        else if (velocidade == 8)
                        {
                            if (j == (i / 8) - 1)
                            {
                                return 5;
                            }
                            else
                            {
                                Thread.Sleep(700);
                                Console.Clear();
                            }
                        }
                    }
                    else if ((j - 2) % 4 == 0)
                    {
                        Console.WriteLine(cor[3] + "                     ██████" + cor[2] + "██████               ");
                        Console.WriteLine(cor[3] + "                  █████████" + cor[2] + "█████████                    ");
                        Console.WriteLine(cor[3] + "                ███████████" + cor[2] + "███████████            ");
                        Console.WriteLine(cor[3] + "              █████████████" + cor[2] + "█████████████                        ");
                        Console.WriteLine(cor[3] + "              ██████" + cor[5] + "X5" + cor[3] + "█████" + cor[2] + "█████" + cor[5] + "X0" + cor[2] + "██████                      ");
                        Console.WriteLine(cor[3] + "            ███████████████" + cor[2] + "███████████████                       ");
                        Console.WriteLine(cor[3] + "            ███████████████" + cor[2] + "███████████████                     ");
                        Console.WriteLine(cor[3] + "           ████████████████" + cor[2] + "████████████████                     ");
                        Console.WriteLine(cor[1] + "           ████████████████" + cor[0] + "████████████████                     ");
                        Console.WriteLine(cor[1] + "            ███████████████" + cor[0] + "███████████████                     ");
                        Console.WriteLine(cor[1] + "            ███████████████" + cor[0] + "███████████████                    ");
                        Console.WriteLine(cor[1] + "              ██████" + cor[5] + "X2" + cor[1] + "█████" + cor[0] + "█████" + cor[5] + "X4" + cor[0] + "██████                      ");
                        Console.WriteLine(cor[1] + "              █████████████" + cor[0] + "█████████████                     ");
                        Console.WriteLine(cor[1] + "                ███████████" + cor[0] + "███████████                     ");
                        Console.WriteLine(cor[1] + "                  █████████" + cor[0] + "█████████");
                        Console.WriteLine(cor[1] + "                     ██████" + cor[0] + "██████");
                        Console.WriteLine(cor[4] + "                                    ");
                        Console.WriteLine("                     ▄▄               ");
                        Console.WriteLine("                   ▄████▄               ");
                        Console.WriteLine("                 ▄████████▄                ");
                        Console.WriteLine("                    ████            ");
                        Console.WriteLine("                    ████              ");
                        Console.WriteLine("                    ████              ");
                        if (velocidade == 2)
                        {
                            Thread.Sleep(150);
                            Console.Clear();
                        }
                        else if (velocidade == 4)
                        {
                            Thread.Sleep(400);
                            Console.Clear();
                        }
                        else if (velocidade == 8)
                        {
                            if (j == (i / 8) - 1)
                            {
                                return 2;
                            }
                            else
                            {
                                Thread.Sleep(700);
                                Console.Clear();
                            }
                        }
                    }
                    else if ((j - 3) % 4 == 0)
                    {
                        Console.WriteLine(cor[1] + "                     ██████" + cor[3] + "██████               ");
                        Console.WriteLine(cor[1] + "                  █████████" + cor[3] + "█████████                    ");
                        Console.WriteLine(cor[1] + "                ███████████" + cor[3] + "███████████            ");
                        Console.WriteLine(cor[1] + "              █████████████" + cor[3] + "█████████████                        ");
                        Console.WriteLine(cor[1] + "              ██████" + cor[5] + "X2" + cor[1] + "█████" + cor[3] + "█████" + cor[5] + "X5" + cor[3] + "██████                      ");
                        Console.WriteLine(cor[1] + "            ███████████████" + cor[3] + "███████████████                       ");
                        Console.WriteLine(cor[1] + "            ███████████████" + cor[3] + "███████████████                     ");
                        Console.WriteLine(cor[1] + "           ████████████████" + cor[3] + "████████████████                     ");
                        Console.WriteLine(cor[0] + "           ████████████████" + cor[2] + "████████████████                     ");
                        Console.WriteLine(cor[0] + "            ███████████████" + cor[2] + "███████████████                     ");
                        Console.WriteLine(cor[0] + "            ███████████████" + cor[2] + "███████████████                   ");
                        Console.WriteLine(cor[0] + "              ██████" + cor[5] + "X4" + cor[0] + "█████" + cor[2] + "█████" + cor[5] + "X0" + cor[2] + "██████                      ");
                        Console.WriteLine(cor[0] + "              █████████████" + cor[2] + "█████████████                     ");
                        Console.WriteLine(cor[0] + "                ███████████" + cor[2] + "███████████                     ");
                        Console.WriteLine(cor[0] + "                  █████████" + cor[2] + "█████████");
                        Console.WriteLine(cor[0] + "                     ██████" + cor[2] + "██████");
                        Console.WriteLine(cor[4] + "                                    ");
                        Console.WriteLine("                     ▄▄               ");
                        Console.WriteLine("                   ▄████▄               ");
                        Console.WriteLine("                 ▄████████▄                ");
                        Console.WriteLine("                    ████            ");
                        Console.WriteLine("                    ████              ");
                        Console.WriteLine("                    ████              ");
                        if (velocidade == 2)
                        {
                            Thread.Sleep(150);
                            Console.Clear();
                        }
                        else if (velocidade == 4)
                        {
                            Thread.Sleep(400);
                            Console.Clear();
                        }
                        else if (velocidade == 8)
                        {
                            if (j == (i / 8) - 1)
                            {
                                return 4;
                            }
                            else
                            {
                                Thread.Sleep(700);
                                Console.Clear();
                            }
                        }
                    }
                }
            }
            return -1;
            
        }
        public static void Loading()
        {
            string cor = "\u001b[38;2;173;216;230m";
            for (int k = 0; k < 7; k++)
            {
                for (int i = 1; i <= 6; i++)
                {
                    if (i == 1)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine(cor + "      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄          ▄▄▄▄▄▄          ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄      ▄████████▄      ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀      ▀████████▀      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 2 || i == 6)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                                   ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                                   ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                                 ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                         ▄▄▄▄▄▄                                   ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                       ▄████████▄        ▄▄▄▄▄▄          ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                      ████████████     ▄████████▄      ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████        ▀████████▀     ████████████    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████          ▀▀▀▀▀▀        ▀████████▀      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀                          ▀▀▀▀▀▀          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 3 || i == 5)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                                   ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                                   ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                        ▄▄▄▄▄▄                                  ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                       ▄████████▄                                 ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                      ████████████       ▄▄▄▄▄▄          ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                      ████████████     ▄████████▄      ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████        ▀████████▀     ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████          ▀▀▀▀▀▀       ████████████    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████                        ▀████████▀      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀                          ▀▀▀▀▀▀          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 4)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                                   ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀          ▄▄▄▄▄▄                             ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                      ▄████████▄                            ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                      ████████████                                ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                      ████████████       ▄▄▄▄▄▄          ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                      ████████████     ▄████████▄      ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████      ▀████████▀     ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████          ▀▀▀▀▀▀       ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████                       ████████████    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████                        ▀████████▀      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀                          ▀▀▀▀▀▀          ▀▀▀▀▀▀   ");
                    }
                }






                for (int i = 1; i <= 6; i++)
                {
                    if (i == 1)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄          ▄▄▄▄▄▄          ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄      ▄████████▄      ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀      ▀████████▀      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 2 || i == 6)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                         ▄▄▄▄▄▄            ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄        ▄████████▄        ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄     ████████████     ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████     ▀████████▀     ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀        ▀▀▀▀▀▀        ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀                          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 3 || i == 5)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                        ▄▄▄▄▄▄             ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                       ▄████████▄            ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄       ████████████       ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄     ████████████     ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████     ▀████████▀     ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████       ▀▀▀▀▀▀       ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀                      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀                          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 4)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                          ▄▄▄▄▄▄                  ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                      ▄████████▄   ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                      ████████████          ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄       ████████████       ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄     ████████████     ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████     ▀████████▀     ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████       ▀▀▀▀▀▀       ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████                    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀                      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀                          ▀▀▀▀▀▀   ");
                    }
                }




                for (int i = 1; i <= 7; i++)
                {
                    if (i == 1 || i == 7)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄          ▄▄▄▄▄▄          ▄▄▄▄▄▄   ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄      ▄████████▄      ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀      ▀████████▀      ▀████████▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀   ");
                    }
                    else if (i == 2 || i == 6)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                           ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                                         ▄▄▄▄▄▄");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄          ▄▄▄▄▄▄        ▄████████▄ ");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄      ▄████████▄     ████████████");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████    ████████████     ▀████████▀");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀      ▀████████▀        ▀▀▀▀▀▀ ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀             ");
                    }
                    else if (i == 3 || i == 5)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                            ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                        ▄▄▄▄▄▄ ");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                                       ▄████████▄");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄          ▄▄▄▄▄▄       ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄      ▄████████▄     ████████████");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████    ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████     ▀████████▀");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████    ████████████       ▀▀▀▀▀▀");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀      ▀████████▀         ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀             ");
                    }
                    else if (i == 4)
                    {
                        Thread.Sleep(60);
                        Console.Clear();
                        Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine(""); Console.WriteLine("");
                        Console.WriteLine("      ▄███▄          ▄██████████████▄    ▄███████████████▄    ██████████████▄      ████   ██████▄          ████   ▄█████████████████▄                                        ");
                        Console.WriteLine("      █████          ████████████████   ▄████▀▀▀▀▀▀▀▀▀████▄   ████▀▀▀▀▀▀▀▀▀███▄    ▀▀▀▀   ████████         ████   ██████████████████▀                                          ▄▄▄▄▄▄  ");
                        Console.WriteLine("      █████          ████▀      ▀████   ████           ████   ████          ███▄          ████ ████        ████   ████▀                                                      ▄████████▄");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████  ████       ████   ████                                                      ████████████");
                        Console.WriteLine("      █████          ████        ████   ████           ████   ████          ████   ████   ████   ████      ████   ████                         ▄▄▄▄▄▄          ▄▄▄▄▄▄       ████████████");
                        Console.WriteLine("      █████          ████        ████   █████▄▄▄▄▄▄▄▄▄█████   ████          ████   ████   ████    ████     ████   ████                       ▄████████▄      ▄████████▄     ████████████");
                        Console.WriteLine("      █████          ████        ████   ███████████████████   ████          ████   ████   ████     ████    ████   ████       ██████████     ████████████    ████████████     ▀████████▀");
                        Console.WriteLine("      █████          ████        ████   █████▀▀▀▀▀▀▀▀▀█████   ████          ████   ████   ████      ████   ████   ████          █████       ████████████    ████████████       ▀▀▀▀▀▀");
                        Console.WriteLine("      █████          ████▄      ▄████   ████           ████   ████          ███▀   ████   ████       ████  ████   ████▄        ▄█████       ████████████    ████████████       ");
                        Console.WriteLine("      ███████████▄   ████████████████   ████           ████   ████▄▄▄▄▄▄▄▄▄███▀    ████   ████        █████████   ███████████████████        ▀████████▀      ▀████████▀         ");
                        Console.WriteLine("      ▀██████████▀   ▀██████████████▀   ███▀           ▀███   ██████████████▀      ████   ████         ▀███████   ▀█████████████████▀          ▀▀▀▀▀▀          ▀▀▀▀▀▀             ");
                    }
                }
            }
            Console.Beep(1500, 300);
            Console.ForegroundColor = ConsoleColor.White;


        }

    }
















    class pokemon
    {
        public string Nome;
        public string Tipo;
        public string Fraqueza;
        public string Resistencia;
        public bool EstaComEfeito;
        public bool TipoEfeito;
        public int VidaMax;
        public int Vida;
        public int Defesa;
        public bool Ataque1;
        public int EneAtaque1;
        public int ValorAtaque1;
        public int ValorAtaqueBonus;
        public bool ValorBonusDireto;
        public int Ataque2;
        public int EneAtaque2;
        public int EneTotal;
        public bool Evolui;
        public string Evolucao;

        /*public pokemon(string nome,string tipo,string fraqueza, string resistencia, int vida, bool ataque1, int eneataque1,int valorataque1,int valorataquebonus,int ataque2,int eneataque2, int enetotal, bool evolui, string evolucao) 
        {
            Nome = nome;
            Tipo = tipo;
            Fraqueza = fraqueza;
            Resistencia = resistencia;
            Vida = vida;
            Ataque1 = ataque1;
            EneAtaque1 = eneataque1;
            ValorAtaque1 = valorataque1;
            ValorAtaqueBonus = valorataquebonus;
            Ataque2 = ataque2;
            EneTotal = enetotal;
            Evolui = evolui;
            Evolucao = evolucao;
        }*/


    }


}
