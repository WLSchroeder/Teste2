﻿using FWL;
using System.Diagnostics;
using System.Net.WebSockets;

using System.Drawing;
// Coisas que faltam fazer
// Sudoku,musicas: (Minecraft, Piratas do caribe, fim de jogo(vitoria), seletor da feira, feira, pokemon, tempo thread, tempo em cada jogo para se calcular a recompensa
bool jogo1 = true, jogo2 = true, jogo3 = true, jogo4 = true, tigrinho = true;
int x = 0, PPT = 0, Simon = 0, Garrafas = 0;
int vida = 3, ChosenGame = 0;
char Dificuldade='a';
string Nick = "slça";
bool Jogo = true, dificul=false;
CWL.Loading();
Console.Clear();
while (Jogo == true)
{
    /*Console.CursorVisible = false;
    Stopwatch cronometro = new Stopwatch();
    cronometro.Start();
    CWL.Escrita("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.");
    Thread.Sleep(1000);
    Console.Clear();
    CWL.Loading();
    Console.Clear();
    CWL.img1();
    Thread.Sleep(1000);
    CWL.Escrita("\n\nMalware : Olá mero mortal. Você ousou entrar no meu domínio... agora prove que merece sair vivo. Você terá que passar por diversos jogos onde será testado a todo momento seu raciocínio e suas habilidades.\n\nMas primeiro, me diga algumas informações:");
    */
    Console.WriteLine("\nNick:");
    Nick = Console.ReadLine();
    while (dificul == false)
    {
        Console.WriteLine("\nDificuldade: ( 1 = Fácil ) ( 2 = Média ) ( 3 = Difícil )");
        Dificuldade = Console.ReadKey().KeyChar;
        
        if (Dificuldade == '1')
        {
            vida = 3;
            dificul=true;
        }
        else if (Dificuldade == '2')
        {
            vida = 2;
            dificul = true;
        }
        else if (Dificuldade == '3')
        {
            vida = 1;
            dificul = true;
        }
        else
        {
            Console.WriteLine("Valor inválido");
            Thread.Sleep(2000);
            Console.Clear();
            dificul = false;
        }
    }
    Jogador jogador1 = new Jogador(Nick, Dificuldade);
    Console.WriteLine("\n\nAHAHAHAHA, Seja bem vindo");
    Thread.Sleep(1000);
    Console.Clear();
    CWL.Loading();
    ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
    CWL.Loading();
    Console.Clear();
    for (int teste = 0; teste < 1; teste++)
    {

        if (ChosenGame == 1)
        {
            PPT = CWL.PPT(vida);
            if (PPT >= 10 && PPT <= 20)
            {
                Console.Clear();
                teste = -1;
                vida = PPT - 10;
                ChosenGame = 1;
            }
            else if (PPT <= 10 && PPT >= 1)
            {
                Console.Clear();
                teste = -1;
                vida = PPT;
                ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
                CWL.Loading();
            }
            else if (PPT >= 21)
            {
                Console.Clear();
                teste = -1;
                jogo1 = false;
                vida = PPT - 20;
                ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
                CWL.Loading();

            }
            else if (PPT == -1)
            {
                Console.Clear();
                teste = 1;
                Jogo = false;
            }
        }
        else if (ChosenGame == 2)
        {

            Simon = CWL.Simon(vida, Dificuldade);
            if (Simon >= 11 && Simon <= 20)
            {
                Console.Clear();
                teste = -1;
                vida = Simon - 10;
                ChosenGame = 2;
            }
            else if (Simon <= 10 && Simon >= 1)
            {
                Console.Clear();
                teste = -1;
                vida = Simon;
                ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
                CWL.Loading();
            }
            else if (Simon >= 21)
            {
                Console.Clear();
                teste = -1;
                jogo2 = false;
                vida = Simon - 20;
                ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
                CWL.Loading();


            }
            else if (Simon == -1)
            {
                Console.Clear();
                teste = 1;
                Jogo = false;
            }
        }
        else if (ChosenGame == 3)
        {
            Garrafas = CWL.Garrafas(vida, Dificuldade);
            if (Garrafas >= 1 && Garrafas <= 10)
            {
                Console.Clear();
                vida = Simon;
                ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
                teste = -1;
                CWL.Loading();
            }
            else if (Garrafas >= 11 && Garrafas <= 20)
            {
                ChosenGame = 3;
                Console.Clear();
                teste = -1;
                vida = Simon - 10;
            }
            else if (Garrafas >= 21)
            {
                Console.Clear();
                teste = -1;
                jogo3 = false;
                vida = Simon - 20;
                ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
                CWL.Loading();

            }
            else if (Garrafas == -1)
            {
                Console.Clear();
                teste = 1;
                Jogo = false;
            }
        }
        else if (ChosenGame == 4)
        {
            CWL.Feira(jogador1.Moedas);
            ChosenGame = CWL.Seletor(jogo1, jogo2, jogo3, jogo4, tigrinho);
            teste--;
        }
        else if (ChosenGame == 5)
        {
            jogador1.Moedas = CWL.Tigrinho(5);
        }
    }
}













/*
CWL.Feira(19);
Jogador jogador1 = new Jogador("sd",1);
jogador1.Moedas=gambiarra.Moedas;
/*



List<pokemon> pokemons = new List<pokemon>();
pokemon Bulbasaur = new pokemon(); Bulbasaur.Nome = "Bulbasaur"; Bulbasaur.Tipo = "Planta"; Bulbasaur.Fraqueza = "Fogo"; Bulbasaur.Resistencia = "Água"; Bulbasaur.EstaComEfeito = false; Bulbasaur.TipoEfeito =false; Bulbasaur.VidaMax = 45; Bulbasaur.Vida = 45; Bulbasaur.Defesa = 49; Bulbasaur.Ataque1 = true; Bulbasaur.EneAtaque1 = 2; Bulbasaur.ValorAtaque1 = 49; Bulbasaur.ValorAtaqueBonus = 10; Bulbasaur.ValorBonusDireto = false; Bulbasaur.Ataque2 = 24; Bulbasaur.EneAtaque2 = 1; Bulbasaur.EneTotal = 0; Bulbasaur.Evolui = true; Bulbasaur.Evolucao = "Ivysaur";
pokemons.Add(Bulbasaur);
pokemon Charmander = new pokemon(); Charmander.Nome = "Charmander"; Charmander.Tipo = "Fogo"; Charmander.Fraqueza = "Água"; Charmander.Resistencia = "Planta"; Charmander.EstaComEfeito = false; Charmander.TipoEfeito = false; Charmander.VidaMax = 39; Charmander.Vida = 39; Charmander.Defesa = 43; Charmander.Ataque1 = true; Charmander.EneAtaque1 = 2; Charmander.ValorAtaque1 = 52; Charmander.ValorAtaqueBonus = 10; Charmander.ValorBonusDireto = false; Charmander.Ataque2 = 26; Charmander.EneAtaque2 = 1; Charmander.EneTotal = 0; Charmander.Evolui = true; Charmander.Evolucao = "Charmeleon";
pokemons.Add(Charmander);
pokemon Ivysaur = new pokemon(); Ivysaur.Nome = "Ivysaur"; Ivysaur.Tipo = "Planta"; Ivysaur.Fraqueza = "Fogo"; Ivysaur.Resistencia = "Água"; Ivysaur.EstaComEfeito = false; Ivysaur.TipoEfeito = false; Ivysaur.VidaMax = 60; Ivysaur.Vida = 60; Ivysaur.Defesa = 63; Ivysaur.Ataque1 = true; Ivysaur.EneAtaque1 = 2; Ivysaur.ValorAtaque1 = 62; Ivysaur.ValorAtaqueBonus = 15; Ivysaur.ValorBonusDireto = false; Ivysaur.Ataque2 = 31; Ivysaur.EneAtaque2 = 1; Ivysaur.EneTotal = 0; Ivysaur.Evolui = true; Ivysaur.Evolucao = "Venusaur";
pokemons.Add(Ivysaur);
pokemon Venusaur = new pokemon(); Venusaur.Nome = "Venusaur"; Venusaur.Tipo = "Planta"; Venusaur.Fraqueza = "Fogo"; Venusaur.Resistencia = "Água"; Venusaur.EstaComEfeito = false; Venusaur.TipoEfeito = false; Venusaur.VidaMax = 80; Venusaur.Vida = 80; Venusaur.Defesa = 83; Venusaur.Ataque1 = true; Venusaur.EneAtaque1 = 3; Venusaur.ValorAtaque1 = 82; Venusaur.ValorAtaqueBonus = 50; Venusaur.ValorBonusDireto = true; Venusaur.Ataque2 = 41; Venusaur.EneAtaque2 = 1; Venusaur.EneTotal = 0; Venusaur.Evolui = false;
pokemons.Add(Venusaur);
pokemon Pikachu = new pokemon(); Pikachu.Nome = "Pikachu"; Pikachu.Tipo = "Elétrico"; Pikachu.Fraqueza = "Terra"; Pikachu.Resistencia = "Elétrico"; Pikachu.EstaComEfeito = false; Pikachu.TipoEfeito = false; Pikachu.VidaMax = 35; Pikachu.Vida = 35; Pikachu.Defesa = 40; Pikachu.Ataque1 = true; Pikachu.EneAtaque1 = 2; Pikachu.ValorAtaque1 = 55; Pikachu.ValorAtaqueBonus = -1; Pikachu.ValorBonusDireto = false; Pikachu.Ataque2 = 30; Pikachu.EneAtaque2 = 1; Pikachu.EneTotal = 0; Pikachu.Evolui = false;
pokemons.Add(Pikachu);*/


